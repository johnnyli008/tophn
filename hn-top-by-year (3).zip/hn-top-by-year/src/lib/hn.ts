export type Story = {
  id: string;
  title: string;
  url: string;
  points: number;
  comments: number;
  author: string;
  createdAt: string;
};

export type HnData = {
  generatedAt: string;
  perYear: number;
  years: Record<string, Story[]>;
};

/** Deterministic formatters (fixed locale + UTC) so server and client always agree. */
const intFmt = new Intl.NumberFormat("en-US");
const dateFmt = new Intl.DateTimeFormat("en-US", {
  month: "short",
  day: "numeric",
  timeZone: "UTC",
});

export function formatInt(n: number): string {
  return intFmt.format(n);
}

export function formatDay(iso: string): string {
  const d = new Date(iso);
  return Number.isNaN(d.getTime()) ? "" : dateFmt.format(d);
}

export function domainOf(url: string): string {
  if (!url) return "news.ycombinator.com";
  try {
    return new URL(url).hostname.replace(/^www\./, "");
  } catch {
    return "";
  }
}

export function itemUrl(id: string): string {
  return `https://news.ycombinator.com/item?id=${id}`;
}
