"use client";

import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  ArrowLeft,
  ArrowRight,
  ChevronDown,
  MessageSquare,
  Search,
  ThumbsUp,
  ExternalLink,
  X,
} from "lucide-react";
import type { HnData, Story } from "@/lib/hn";
import { domainOf, formatDay, formatInt, itemUrl } from "@/lib/hn";
import { cn } from "@/lib/utils";

type Props = {
  data: HnData;
  years: string[];
  initialYear: string;
  initialQuery: string;
};

type SearchHit = { year: string; story: Story };

const ALL_TIME = "all";

function SearchInput({
  value,
  onChange,
  inputRef,
  className,
}: {
  value: string;
  onChange: (v: string) => void;
  inputRef: React.RefObject<HTMLInputElement | null>;
  className?: string;
}) {
  return (
    <div className={cn("relative", className)}>
      <Search
        className="pointer-events-none absolute left-2.5 top-1/2 h-4 w-4 -translate-y-1/2 text-stone-400"
        aria-hidden="true"
      />
      <input
        ref={inputRef}
        type="text"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        onKeyDown={(e) => {
          if (e.key === "Escape") {
            onChange("");
            e.currentTarget.blur();
          }
        }}
        placeholder="Search all stories…"
        aria-label="Search all stories"
        autoComplete="off"
        spellCheck={false}
        className="h-9 w-full rounded-md border border-stone-200 bg-white pl-8 pr-8 text-sm text-stone-800 placeholder:text-stone-400 outline-none transition-colors focus:border-[#e85d04] focus:ring-1 focus:ring-[#e85d04]"
      />
      {value.length > 0 && (
        <button
          type="button"
          onClick={() => {
            onChange("");
            inputRef.current?.focus();
          }}
          className="absolute right-1.5 top-1/2 -translate-y-1/2 rounded p-1 text-stone-400 transition hover:bg-stone-100 hover:text-stone-700"
          aria-label="Clear search"
        >
          <X className="h-3.5 w-3.5" aria-hidden="true" />
        </button>
      )}
    </div>
  );
}

function StoryRow({
  story,
  rank,
  yearTag,
  onYearPick,
}: {
  story: Story;
  rank: number;
  yearTag?: string;
  onYearPick?: (year: string) => void;
}) {
  const link = story.url || itemUrl(story.id);
  const domain = domainOf(story.url);

  return (
    <li className="group flex items-start gap-3 px-4 py-3.5 transition-colors hover:bg-orange-50/60 sm:gap-5 sm:px-6">
      <span
        className={cn(
          "mt-0.5 w-8 shrink-0 text-right text-[15px] font-semibold tabular-nums",
          rank <= 3 ? "text-[#e85d04]" : "text-stone-300 group-hover:text-stone-400"
        )}
        aria-hidden="true"
      >
        {rank}
      </span>

      <div className="min-w-0 flex-1">
        <h3 className="text-[15px] leading-snug font-medium text-stone-900">
          <a
            href={link}
            target="_blank"
            rel="noopener noreferrer"
            className="decoration-orange-300 underline-offset-2 hover:underline"
          >
            {story.title}
          </a>
          <span className="ml-2 align-middle text-xs font-normal whitespace-nowrap text-stone-400">
            ({domain})
          </span>
        </h3>

        <div className="mt-1.5 flex flex-wrap items-center gap-x-4 gap-y-1 text-xs text-stone-500">
          <span className="inline-flex items-center gap-1 font-medium text-[#e85d04]">
            <ThumbsUp className="h-3.5 w-3.5" aria-hidden="true" />
            {formatInt(story.points)}
          </span>
          <a
            href={itemUrl(story.id)}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1 transition-colors hover:text-stone-900"
            title="Discussion on Hacker News"
          >
            <MessageSquare className="h-3.5 w-3.5" aria-hidden="true" />
            {formatInt(story.comments)} comments
          </a>
          <span>
            by <span className="text-stone-600">{story.author}</span>
          </span>
          <span>{formatDay(story.createdAt)}</span>
          {yearTag && onYearPick && (
            <button
              type="button"
              onClick={() => onYearPick(yearTag)}
              className="rounded bg-stone-100 px-1.5 py-0.5 text-[10px] font-semibold tracking-wide text-stone-500 tabular-nums uppercase transition-colors hover:bg-[#e85d04] hover:text-white"
              title={`Show all top stories of ${yearTag}`}
            >
              {yearTag}
            </button>
          )}
          {!story.url && (
            <span className="inline-flex items-center gap-0.5 rounded bg-stone-100 px-1.5 py-0.5 text-[10px] font-medium tracking-wide text-stone-500 uppercase">
              {/^(Ask|Tell|Show) HN/.test(story.title)
                ? story.title.slice(0, story.title.indexOf(" HN"))
                : "Text-only"}
            </span>
          )}
        </div>
      </div>

      <a
        href={itemUrl(story.id)}
        target="_blank"
        rel="noopener noreferrer"
        className="mt-0.5 hidden shrink-0 rounded-md p-1.5 text-stone-300 opacity-0 transition group-hover:opacity-100 hover:bg-stone-100 hover:text-stone-600 focus-visible:opacity-100 sm:block"
        aria-label={`Discuss "${story.title}" on Hacker News`}
      >
        <ExternalLink className="h-4 w-4" aria-hidden="true" />
      </a>
    </li>
  );
}

export default function HnExplorer({
  data,
  years,
  initialYear,
  initialQuery = "",
}: Props) {
  const [year, setYear] = useState(initialYear);
  const [query, setQuery] = useState(initialQuery);
  const searchRef = useRef<HTMLInputElement>(null);
  const mobileSearchRef = useRef<HTMLInputElement>(null);
  const chipRefs = useRef(new Map<string, HTMLButtonElement>());

  const trimmed = query.trim().toLowerCase();
  const searchMode = trimmed.length > 0;

  // Strip sequence: real years followed by the all-time pseudo-entry.
  const chips = useMemo(() => [...years, ALL_TIME], [years]);
  const isAllTime = year === ALL_TIME;
  const latestYear = years[years.length - 1];
  const snapshotDay = formatDay(data.generatedAt);

  const yearView = useMemo(() => data.years[year] ?? [], [data, year]);

  // Exact from the bundled archive: any all-time top-25 story must also be a
  // top-25 story within its own year, so the yearly union contains all of it.
  // Each row keeps its source year so the view can show a year tag — a bare
  // "Mar 14" date is ambiguous across two decades of stories.
  const allTimeView = useMemo(() => {
    const flat = years.flatMap((y) =>
      (data.years[y] ?? []).map((story) => ({ story, year: y })),
    );
    return flat.sort((a, b) => b.story.points - a.story.points).slice(0, 25);
  }, [data, years]);
  const allTimeYearOf = useMemo(
    () => new Map(allTimeView.map((r) => [r.story.id, r.year])),
    [allTimeView],
  );

  const stories = useMemo(
    () => (isAllTime ? allTimeView.map((r) => r.story) : yearView),
    [isAllTime, allTimeView, yearView],
  );

  // Cross-archive search over the bundled dataset: title, author, domain.
  // Multi-word queries match AND across any position ("xz backdoor" finds the
  // 2024 xz story). Client-side only — instant, no network. The active query
  // is mirrored to ?q= in the URL (see applyQuery) so results can be shared.
  const results = useMemo<SearchHit[]>(() => {
    if (!searchMode) return [];
    const terms = trimmed.split(/\s+/);
    const out: SearchHit[] = [];
    for (const y of years) {
      for (const s of data.years[y] ?? []) {
        const hay = `${s.title} ${s.author} ${domainOf(s.url)}`.toLowerCase();
        if (terms.every((t) => hay.includes(t))) out.push({ year: y, story: s });
      }
    }
    out.sort((a, b) => b.story.points - a.story.points);
    return out;
  }, [searchMode, trimmed, data, years]);

  const summary = useMemo(() => {
    const totalPoints = stories.reduce((acc, s) => acc + s.points, 0);
    const totalComments = stories.reduce((acc, s) => acc + s.comments, 0);
    return { totalPoints, totalComments };
  }, [stories]);

  // Search state mirrors ?q= in the URL (replaceState: typing must not spam
  // history) so results survive a refresh and can be shared like ?year= links.
  const applyQuery = useCallback((v: string) => {
    setQuery(v);
    try {
      const url = new URL(window.location.href);
      const q = v.trim();
      if (q) url.searchParams.set("q", q);
      else url.searchParams.delete("q");
      window.history.replaceState(null, "", url);
    } catch {
      /* no-op */
    }
  }, []);

  // Year changes push a history entry so the browser Back/Forward buttons
  // walk the year trail (v2 used replaceState, which made Back exit the site).
  const selectYear = useCallback(
    (y: string) => {
      const revisiting = y === year;
      setQuery("");
      if (revisiting && !searchMode) return;
      setYear(y);
      try {
        const url = new URL(window.location.href);
        url.searchParams.set("year", y);
        url.searchParams.delete("q");
        window.history.pushState({ year: y }, "", url);
      } catch {
        /* no-op */
      }
      if (typeof window !== "undefined" && window.scrollY > 240) {
        window.scrollTo({ top: 0 });
      }
    },
    [year, searchMode]
  );

  const stepYear = useCallback(
    (dir: -1 | 1) => {
      const i = chips.indexOf(year);
      const next = chips[Math.min(Math.max(i + dir, 0), chips.length - 1)];
      if (next && next !== year) selectYear(next);
    },
    [year, chips, selectYear]
  );

  // Back/Forward buttons re-sync the view with the URL.
  useEffect(() => {
    const onPop = () => {
      try {
        const params = new URLSearchParams(window.location.search);
        const fromUrl = params.get("year");
        const valid =
          fromUrl && (years.includes(fromUrl) || fromUrl === ALL_TIME)
            ? fromUrl
            : latestYear;
        setYear(valid);
        setQuery(params.get("q") ?? "");
      } catch {
        /* no-op */
      }
    };
    window.addEventListener("popstate", onPop);
    return () => window.removeEventListener("popstate", onPop);
  }, [years, latestYear]);

  // Keyboard: ← / → flip years, / focuses search. Skips while typing in a field.
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      const target = e.target as HTMLElement | null;
      const inField =
        target &&
        (target.tagName === "INPUT" ||
          target.tagName === "TEXTAREA" ||
          target.isContentEditable);
      if (e.key === "/" && !inField) {
        e.preventDefault();
        searchRef.current?.focus();
        return;
      }
      if (inField) return;
      if (e.key === "ArrowLeft") {
        e.preventDefault();
        stepYear(-1);
      } else if (e.key === "ArrowRight") {
        e.preventDefault();
        stepYear(1);
      }
    };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [stepYear]);

  // Scroll the active chip into view whenever the view changes.
  useEffect(() => {
    chipRefs.current.get(year)?.scrollIntoView({
      behavior: "smooth",
      inline: "center",
      block: "nearest",
    });
  }, [year]);

  const listKey = searchMode ? `q-${trimmed}` : `y-${year}`;

  return (
    <div className="flex flex-1 flex-col">
      {/* Single sticky block: header + (mobile search) + year strip. */}
      <div className="sticky top-0 z-20 border-b border-stone-200/80 bg-[#faf9f6]/95 backdrop-blur">
        <div className="mx-auto flex h-14 max-w-3xl items-center gap-3 px-4 sm:px-6">
          <span
            className="flex h-8 w-8 shrink-0 items-center justify-center rounded-md bg-[#ff6600] text-lg font-bold text-white select-none"
            aria-hidden="true"
          >
            Y
          </span>
          <div className="min-w-0 flex-1">
            <h1 className="truncate text-[15px] leading-tight font-semibold tracking-tight">
              Hacker News — Top Stories by Year
            </h1>
            <p className="hidden truncate text-xs text-stone-500 sm:block">
              {years[0]}–{latestYear} · the most upvoted stories of every year
            </p>
          </div>
          <SearchInput
            value={query}
            onChange={applyQuery}
            inputRef={searchRef}
            className="hidden w-52 sm:block lg:w-64"
          />
        </div>

        {/* Mobile search row */}
        <div className="border-t border-stone-200/70 px-3 py-2 sm:hidden">
          <SearchInput
            value={query}
            onChange={applyQuery}
            inputRef={mobileSearchRef}
            className="w-full"
          />
        </div>

        {/* Year strip */}
        <div className="border-t border-stone-200/70">
          <div className="mx-auto flex max-w-3xl items-center gap-1 px-2 py-2.5 sm:px-4">
            <button
              type="button"
              onClick={() => stepYear(-1)}
              disabled={year === chips[0]}
              className="rounded-md p-2 text-stone-500 transition hover:bg-stone-100 hover:text-stone-900 disabled:pointer-events-none disabled:opacity-30"
              aria-label="Previous year"
            >
              <ArrowLeft className="h-4 w-4" aria-hidden="true" />
            </button>

            <div
              className="scrollbar-thin flex flex-1 gap-1.5 overflow-x-auto scroll-smooth px-1 py-0.5"
              role="tablist"
              aria-label="Select a year"
            >
              {chips.map((y) => {
                const active = y === year;
                const isAllTimeChip = y === ALL_TIME;
                return (
                  <button
                    key={y}
                    ref={(el) => {
                      if (el) chipRefs.current.set(y, el);
                      else chipRefs.current.delete(y);
                    }}
                    type="button"
                    role="tab"
                    aria-selected={active}
                    aria-controls="hn-panel"
                    onClick={() => selectYear(y)}
                    title={
                      isAllTimeChip
                        ? "The 25 most upvoted stories ever"
                        : y === latestYear
                          ? `${y} — year in progress`
                          : undefined
                    }
                    className={cn(
                      "shrink-0 rounded-full border px-3 py-1 text-[13px] font-medium transition-all duration-150",
                      isAllTimeChip && "tabular-nums",
                      active
                        ? "border-transparent bg-[#e85d04] text-white shadow-sm"
                        : "border-stone-200 bg-white text-stone-600 hover:border-stone-300 hover:text-stone-900"
                    )}
                  >
                    {isAllTimeChip ? "All time" : y}
                  </button>
                );
              })}
            </div>

            <button
              type="button"
              onClick={() => stepYear(1)}
              disabled={year === chips[chips.length - 1]}
              className="rounded-md p-2 text-stone-500 transition hover:bg-stone-100 hover:text-stone-900 disabled:pointer-events-none disabled:opacity-30"
              aria-label="Next year"
            >
              <ArrowRight className="h-4 w-4" aria-hidden="true" />
            </button>
          </div>
        </div>
      </div>

      {/* Summary line — announced to screen readers on change */}
      <div className="mx-auto w-full max-w-3xl px-4 pt-5 sm:px-6">
        {searchMode ? (
          <p aria-live="polite" className="text-sm text-stone-500">
            <span className="font-semibold text-stone-800">
              {formatInt(results.length)}
            </span>{" "}
            result{results.length === 1 ? "" : "s"} for{" "}
            <span className="font-semibold text-stone-800">
              &ldquo;{query.trim()}&rdquo;
            </span>
            <span className="mx-2 text-stone-300">·</span>
            all years {years[0]}–{latestYear}
            <span className="mx-2 text-stone-300">·</span>
            sorted by points
          </p>
        ) : isAllTime ? (
          <p aria-live="polite" className="text-sm text-stone-500">
            The <span className="font-semibold text-stone-800">25</span>{" "}
            most-upvoted stories of all time
            <span className="mx-2 text-stone-300">·</span>
            {years[0]}–{latestYear}
            <span className="mx-2 text-stone-300">·</span>
            {formatInt(summary.totalPoints)} combined points
            <span className="mx-2 text-stone-300">·</span>
            {formatInt(summary.totalComments)} comments
          </p>
        ) : (
          <p aria-live="polite" className="text-sm text-stone-500">
            The {stories.length} most-upvoted stories of{" "}
            <span className="font-semibold text-stone-800">{year}</span>
            {year === latestYear && (
              <span className="ml-1.5 text-amber-700">
                (year in progress — through {snapshotDay})
              </span>
            )}
            <span className="mx-2 text-stone-300">·</span>
            {formatInt(summary.totalPoints)} combined points
            <span className="mx-2 text-stone-300">·</span>
            {formatInt(summary.totalComments)} comments
          </p>
        )}
      </div>

      {/* Story list */}
      <main className="mx-auto w-full max-w-3xl flex-1 px-0 pb-10 sm:px-6">
        <div
          id="hn-panel"
          role="tabpanel"
          aria-label={
            searchMode ? "Search results" : isAllTime ? "All-time top stories" : `Top stories of ${year}`
          }
          className="mt-4 overflow-hidden rounded-xl border border-stone-200/90 bg-white shadow-sm"
        >
          <ol key={listKey} className="hn-list-fade divide-y divide-stone-100">
            {searchMode
              ? results.map((hit, i) => (
                  <StoryRow
                    key={hit.story.id}
                    story={hit.story}
                    rank={i + 1}
                    yearTag={hit.year}
                    onYearPick={selectYear}
                  />
                ))
              : stories.map((story, i) => (
                  <StoryRow
                    key={story.id}
                    story={story}
                    rank={i + 1}
                    yearTag={isAllTime ? allTimeYearOf.get(story.id) : undefined}
                    onYearPick={isAllTime ? selectYear : undefined}
                  />
                ))}
          </ol>
          {((searchMode && results.length === 0) ||
            (!searchMode && stories.length === 0)) && (
            <p className="px-6 py-12 text-center text-sm text-stone-400">
              {searchMode
                ? `No stories match “${query.trim()}”.`
                : `No stories found for ${year === ALL_TIME ? "all time" : year}.`}
            </p>
          )}
        </div>

        <p className="mt-4 flex items-center justify-center gap-1 text-xs text-stone-400">
          <ChevronDown className="h-3 w-3" aria-hidden="true" />
          {searchMode
            ? "Press Esc to clear the search"
            : "← / → to flip years · / to search the archive"}
        </p>
      </main>
    </div>
  );
}
