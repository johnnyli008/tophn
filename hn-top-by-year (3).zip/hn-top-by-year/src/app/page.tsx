/**
 * Release policy: changes are limited to bug fixes and features that
 * demonstrably help view the top HN stories of each year. No speculative
 * additions (new deps, DB, auth, theming, analytics, decorative animation).
 */
import rawData from "@/data/hn-top-stories.json";
import HnExplorer from "@/components/hn-explorer";
import type { HnData } from "@/lib/hn";

const data = rawData as unknown as HnData;
const years = Object.keys(data.years).sort();
const latestYear = years[years.length - 1] ?? "2026";

export default async function Home({
  searchParams,
}: {
  searchParams: Promise<{ year?: string; q?: string }>;
}) {
  const { year: yearParam, q: qParam } = await searchParams;
  const initialYear =
    yearParam === "all"
      ? "all"
      : yearParam && years.includes(yearParam)
        ? yearParam
        : latestYear;

  return (
    <div className="flex min-h-screen flex-col bg-[#faf9f6] text-stone-900">
      <HnExplorer
        data={data}
        years={years}
        initialYear={initialYear}
        initialQuery={(qParam ?? "").trim().slice(0, 200)}
      />

      <footer className="mt-auto border-t border-stone-200/80 bg-white/60">
        <div className="mx-auto max-w-3xl px-4 py-4 text-center text-xs text-stone-400 sm:px-6">
          Data from the Algolia HN Search API, snapshot of{" "}
          {data.generatedAt.slice(0, 10)} · not affiliated with Hacker News / Y Combinator
        </div>
      </footer>
    </div>
  );
}
