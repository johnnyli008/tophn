#!/usr/bin/env python3
"""Fetch the top Hacker News stories of each year from the Algolia HN API
and regenerate src/data/hn-top-stories.json used by the app.

HN launched in Feb 2007 -> years 2007..current year.
Sorted by popularity (default /search ordering) with numericFilters on
created_at_i so each query covers exactly one calendar year (UTC).

Usage:  python3 scripts/fetch_hn.py        (or: npm run fetch-data)
Needs:  Python 3.10+, no third-party packages.
"""

import json
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
OUT_PATH = REPO_ROOT / "src" / "data" / "hn-top-stories.json"
PER_YEAR = 25
NOW = int(time.time())


def year_range(year: int) -> tuple[int, int]:
    start = int(datetime(year, 1, 1, tzinfo=timezone.utc).timestamp())
    end = int(datetime(year + 1, 1, 1, tzinfo=timezone.utc).timestamp())
    return start, min(end, NOW)


def fetch_year(year: int) -> list[dict]:
    start, end = year_range(year)
    # HN's early years were tiny, so a 100-point floor drops the true
    # top-25 tail (2007 only had 17 stories above 100 points). Lower the
    # floor for those years; the popularity ordering keeps the list correct.
    min_points = 20 if year <= 2007 else 100
    params = {
        "tags": "story",
        "hitsPerPage": str(PER_YEAR),
        "numericFilters": f"points>{min_points},created_at_i>{start},created_at_i<{end}",
    }
    url = "https://hn.algolia.com/api/v1/search?" + urllib.parse.urlencode(params)
    req = urllib.request.Request(url, headers={"User-Agent": "hn-top-by-year/1.0"})
    with urllib.request.urlopen(req, timeout=30) as resp:
        payload = json.load(resp)

    stories = []
    for hit in payload.get("hits", []):
        if hit.get("title") is None:
            continue
        stories.append(
            {
                "id": hit["objectID"],
                "title": hit["title"],
                "url": hit.get("url") or "",
                "points": hit.get("points") or 0,
                "comments": hit.get("num_comments") or 0,
                "author": hit.get("author") or "",
                "createdAt": hit.get("created_at") or "",
            }
        )
    # Algolia already sorts by popularity; sort defensively by points desc.
    stories.sort(key=lambda s: s["points"], reverse=True)
    return stories[:PER_YEAR]


def main() -> None:
    current_year = datetime.now(timezone.utc).year
    result: dict[str, object] = {
        "generatedAt": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "perYear": PER_YEAR,
        "years": {},
    }
    years: dict[str, list[dict]] = {}
    for year in range(2007, current_year + 1):
        for attempt in range(3):
            try:
                stories = fetch_year(year)
                years[str(year)] = stories
                top = stories[0] if stories else None
                print(
                    f"{year}: {len(stories)} stories"
                    + (f" | top: {top['points']} pts - {top['title'][:60]}" if top else "")
                )
                break
            except Exception as exc:  # noqa: BLE001
                print(f"{year}: attempt {attempt + 1} failed: {exc}")
                time.sleep(2)
        else:
            raise SystemExit(f"Failed to fetch year {year}")
        time.sleep(0.4)

    result["years"] = years
    OUT_PATH.parent.mkdir(parents=True, exist_ok=True)
    OUT_PATH.write_text(json.dumps(result, ensure_ascii=False, separators=(",", ":")))
    size_kb = OUT_PATH.stat().st_size / 1024
    print(f"Wrote {OUT_PATH} ({size_kb:.1f} KB)")


if __name__ == "__main__":
    main()
