# HN Top Stories by Year

The most upvoted [Hacker News](https://news.ycombinator.com) stories of every year, 2007 to today — with instant search across the whole archive.

![Screenshot of HN Top Stories by Year](docs/screenshot.png)

## Why it loads instantly

There is no API and no database. The top 25 stories of every year are pre-fetched from the [Algolia HN Search API](https://hn.algolia.com/api/v1) into a single static JSON file (`src/data/hn-top-stories.json`, ~105 KB) that ships with the app. The page renders server-side in milliseconds, and switching years — or searching — is a pure client-side state change with **zero network requests**.

## Features

- **Top 25 stories of each year**, ranked, with points, comment counts, authors, dates and source domains
- **All-time top 25** — the biggest stories ever, one click away on the year strip (`?year=all`); every row is tagged with its year and jumps straight back to that year
- **Archive-wide search** — filter all ~500 stories by title, author or domain; multi-word queries match across any position; results link straight back to the year view
- **Keyboard-first** — `←` / `→` flip years, `/` focuses search, `Esc` clears it
- **Shareable URLs** — `/?year=2016` renders that year server-side; search results live at their own `?q=` link (refresh keeps them, copy shares them)
- **Accessible** — semantic tabs, `aria-live` announcements, keyboard operable throughout
- Responsive, no tracking, no cookies, no external requests at runtime

## Getting started

Requires Node.js 20.9+ (or [Bun](https://bun.sh)).

```bash
bun install        # or: npm install
bun run dev        # or: npm run dev
```

Open http://localhost:3000.

| Script               | What it does                          |
| -------------------- | ------------------------------------- |
| `dev`                | Start the dev server on port 3000     |
| `build`              | Production build                      |
| `start`              | Serve the production build            |
| `lint`               | ESLint (Next.js core-web-vitals)      |
| `fetch-data`         | Re-fetch the dataset (see below)      |

## Refreshing the data

The bundled snapshot was generated on **2026-10-31**. To update it:

```bash
npm run fetch-data        # python3 scripts/fetch_hn.py
```

Needs Python 3.10+ only (standard library, no packages). The script re-queries the Algolia HN API per year and rewrites `src/data/hn-top-stories.json`; commit the result. Note that the current year's ranking keeps changing until the year ends.

## Project structure

```
src/
├── app/
│   ├── layout.tsx          # metadata + fonts
│   ├── page.tsx            # server component: reads ?year=, renders the explorer
│   ├── globals.css         # Tailwind v4 theme + small custom animations
│   └── icon.svg            # favicon
├── components/
│   └── hn-explorer.tsx     # the whole UI (client component)
├── lib/
│   ├── hn.ts               # types + deterministic formatters
│   └── utils.ts            # cn() helper
└── data/
    └── hn-top-stories.json # the archive (generated, committed)
scripts/
└── fetch_hn.py             # dataset generator
```

## Data source & disclaimer

Story data comes from the public [Algolia HN Search API](https://hn.algolia.com). "Top" means the highest-scoring stories posted within each calendar year (UTC), as returned by Algolia's popularity ranking at fetch time.

This project is not affiliated with Hacker News or Y Combinator.

## License

[MIT](LICENSE)
