#!/usr/bin/env python3
"""
hn-top-by-year :: site builder
Injects data.json into template.html and writes everything needed to deploy:

    index.html            the entire site (CSS + JS + dataset inline)
    sw.js                 optional service worker (network-first, offline cache)
    manifest.webmanifest  PWA manifest (installable)
    icon.svg              app icon used by the manifest

index.html alone is still fully functional (even on file://); the other three
files only add installability / offline shell when deployed alongside it.

Usage:
    python3 build.py            # build into the same folder
"""

import json
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent


def fail(msg: str) -> int:
    print(msg, file=sys.stderr)
    return 1


def main() -> int:
    data_path = ROOT / "data.json"
    tpl_path = ROOT / "template.html"
    sw_tpl_path = ROOT / "template.sw.js"
    icon_path = ROOT / "icon.svg"

    if not data_path.exists():
        return fail("data.json missing — run scripts/fetch_top_stories.py first")
    tpl = tpl_path.read_text(encoding="utf-8")
    if tpl.count("__DATA_JSON__") != 1:
        return fail("template.html must contain exactly one __DATA_JSON__ placeholder")

    m = re.search(r"var VERSION = '([^']+)'", tpl)
    if not m:
        return fail("could not read VERSION from template.html")
    version = m.group(1)

    payload = json.loads(data_path.read_text(encoding="utf-8"))
    data = json.dumps(payload, ensure_ascii=False, separators=(",", ":"))
    # Escape '<' so a title containing "</script>" can never break out of the
    # embedded JSON block (\u003c is a valid JSON escape, decoded on parse).
    data = data.replace("<", "\\u003c")

    index = tpl.replace("__DATA_JSON__", data)
    (ROOT / "index.html").write_text(index, encoding="utf-8")
    print(f"built index.html          {len(index.encode('utf-8')) / 1024:7.0f} KB  (v{version})")

    sw = sw_tpl_path.read_text(encoding="utf-8").replace("__CACHE_VERSION__", f"hn-top-by-year-v{version}")
    (ROOT / "sw.js").write_text(sw, encoding="utf-8")
    print("built sw.js               (optional service worker)")

    manifest = {
        "name": "HN Top by Year",
        "short_name": "HN Top",
        "description": "The top Hacker News stories of every year.",
        "start_url": "./",
        "scope": "./",
        "display": "standalone",
        "background_color": "#0f1216",
        "theme_color": "#ff6600",
        "icons": [{"src": "icon.svg", "sizes": "any", "type": "image/svg+xml", "purpose": "any"}],
    }
    (ROOT / "manifest.webmanifest").write_text(json.dumps(manifest, indent=2) + "\n", encoding="utf-8")
    print("built manifest.webmanifest")

    (ROOT / "icon.svg").write_text(icon_path.read_text(encoding="utf-8"), encoding="utf-8")
    print("built icon.svg")

    return 0


if __name__ == "__main__":
    sys.exit(main())
