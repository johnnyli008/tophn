# Changelog

All notable changes to this project are documented here.
Format based on [Keep a Changelog](https://keepachangelog.com/en/1.1.0/);
versioning follows [SemVer](https://semver.org/): patch = bug fixes,
minor = quality-of-life features, major = breaking changes.

## [Unreleased]

Ideas parked for **v1.2.0** (not started):

- Native share button (`navigator.share`) on mobile
- `apple-touch-icon` PNG for iOS home-screen installs
- Per-year jump list (`g` then `Tab` to autocomplete years)
- Optional "show N stories per year" setting persisted alongside the theme

## [1.1.4] — 2026-11-01

Final QA release: 155 automated checks across 5 regression suites
(keyboard, filter, go-to-year HUD, themes, per-year view cache, restricted
contexts, offline PWA, all 20 years × 25 rows) — all green.

### Fixed

- A garbage URL hash typed at runtime (e.g. editing the address bar to
  `#abc`) is now normalized back to the current year's hash instead of
  being left in the URL, so reloading later lands where the user actually
  was. Fresh loads with a garbage hash already opened the latest year.
- Year round-trips keep their per-year filter: leaving a filtered year and
  returning to it restores the filter text, the filtered row count,
  selection and scroll position (verified end-to-end).

## [1.1.3] — 2026-11-01

Final QA pass; no visible layout changes.

### Fixed

- **Enter double-activation** — with focus on a button or link (year pill,
  prev/next, theme, help, a story title…), pressing `Enter` natively
  activated that element *and* opened the selected story in a new tab.
  `Enter` now only opens a story when no button/link is focused; `o` and
  `c` are unchanged.
- **Help dialog focus management** — opening the `?` overlay now moves focus
  to its close button and `Esc`/close returns focus to the element that
  opened it (WAI-ARIA modal dialog pattern).

## [1.1.2] — 2026-11-01

### Removed

- The blinking orange text-caret in the go-to-year HUD (`g`). The `____`
  underscores already fill in as digits are typed, so the caret was redundant
  and distracting; it was also the page's only animation. The HUD is now
  completely static.

## [1.1.1] — 2026-11-01

Bug-fix release; no shortcut or data changes.

### Fixed

- **Blank page on first open** in embedded/restricted contexts. When the page
  is rendered inside an `about:srcdoc` or `blob:` frame (how many embedded
  previews display a downloaded `index.html`), `history.replaceState()` at
  init threw a `SecurityError` *before* the story list was rendered, leaving
  the site empty. History/hash handling is now guarded and runs strictly
  **after** the first render — rendering can no longer be blocked by it.
- **Default year is now always the most recent one** (currently 2026) when no
  `#year` hash is present. The "remember last visited year" behaviour is
  removed; explicit `#year` links still deep-link to that year.
- The active year pill was not exactly centred in the year rail on wide
  screens (pill offsets were measured from the page edge instead of the rail).
- The header `theme-color` (mobile browser chrome) now follows an explicit
  light/dark toggle instead of only the OS preference.
- Service worker: only cacheable same-origin OK-responses are written to the
  cache, and the offline fallback can no longer resolve to `undefined`.
- Go-to-year `popstate` handling is a no-op when the hash resolves to the
  year already on screen.

## [1.1.0] — 2026-11-01

Quality-of-life release (no data-format or shortcut breaking changes).

### Added

- **In-page filter** — press `/` to filter the current year's list by title,
  author or domain. `Enter` opens the top hit, `↓` selects it, `Esc` clears.
  The subtitle shows "N of 25 shown"; an empty result shows a hint instead of
  a blank list.
- **Theme toggle** — header button cycles auto → light → dark, persisted in
  `localStorage`; auto follows the OS `prefers-color-scheme` as before.
- **Remember last visited year** — reopening the site without a hash lands on
  the year you last viewed; an explicit `#year` hash still wins.
- **Copy shortcuts** — `y` copies the selected story's article link,
  `Shift+y` copies the HN discussion link; a toast confirms each copy.
- **`j`/`k` auto-repeat acceleration** — holding the key accelerates through
  long lists (step 1 → 3 → 8 after a few repeats); any key-up resets it.
- **Per-year view cache** — leaving a year snapshots its rendered list,
  filter, selection and scroll position; switching back restores all of it
  instantly (no re-render, no lost place).
- **PWA support** — `manifest.webmanifest`, `icon.svg` and an optional
  network-first service worker (`sw.js`) so the installed app keeps working
  offline. `index.html` alone remains fully functional; the service worker is
  silently skipped on `file://`.
- **Share metadata** — Open Graph / Twitter card tags and light/dark
  `theme-color` for mobile browser chrome.

### Fixed

- In go-to-year mode, pressing a non-digit key cancelled the mode *and*
  leaked through to that key's own shortcut; the cancelling key is now
  swallowed.
- Quick-open (`1`–`9`) and `End` operated on the full year list even when a
  filter was active; they now operate on what is on screen.
- `Shift+y` could be reported by some layouts as `key:'y'` with `shiftKey`
  set, copying the wrong link; both forms are now handled.
- Year switching could cause stray vertical scroll jumps (the year-rail
  auto-center used `scrollIntoView`, which may also scroll the page, and
  instant scrolls raced the page's CSS `scroll-behavior:smooth`). Rail
  centering is now scoped to the rail and page scrolls are truly instant.

## [1.0.0] — 2026-11-01

Initial release.

### Added

- Single-file static site: top 25 Hacker News stories for each year
  2007 → 2026, ranked by points, embedded as JSON inside `index.html`
  (no runtime network requests, no cookies, no tracking)
- Full keyboard navigation: year switching (`←`/`→`/`h`/`l`), list
  selection (`↑`/`↓`/`j`/`k`, `Home`/`End`), open story (`Enter`/`o`),
  open discussion (`c`), quick-open ranks 1–9, go-to-year mode
  (`g` + year + `Enter`), help overlay (`?`), `Esc` to dismiss
- Mouse/touch support: clickable year rail, prev/next buttons, story and
  comment links; hint bar auto-hides on touch devices
- Shareable URLs: year synced to the location hash, Back/Forward support
- Dark and light themes via `prefers-color-scheme`;
  `prefers-reduced-motion` respected
- Data build pipeline: `fetch_top_stories.py` (HN Algolia API, throttled,
  retries, dedupe, point-sorted) + `build.py` (single-file bundler)
- Help overlay listing every shortcut, opened via `?` or the header button

[Unreleased]: https://example.com/hn-top-by-year/compare/v1.1.4...HEAD
[1.1.4]: https://example.com/hn-top-by-year/compare/v1.1.3...v1.1.4
[1.1.3]: https://example.com/hn-top-by-year/compare/v1.1.2...v1.1.3
[1.1.2]: https://example.com/hn-top-by-year/compare/v1.1.1...v1.1.2
[1.1.1]: https://example.com/hn-top-by-year/compare/v1.1.0...v1.1.1
[1.1.0]: https://example.com/hn-top-by-year/compare/v1.0.0...v1.1.0
[1.0.0]: https://example.com/hn-top-by-year/releases/tag/v1.0.0
