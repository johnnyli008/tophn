# HN Top by Year

The highest-scoring Hacker News stories of every year, 2007 → today.
One HTML file. No dependencies. Works offline. Fully keyboard-driven.

## Quick start

Open `index.html` in any browser — that's it. The whole app and the
500-story dataset are inside that single file, so it even works straight
from disk (`file://`) with no server and no internet.

To also get install/offline (PWA) support, serve the folder instead:

```bash
python3 -m http.server 4173   # → http://localhost:4173
```

## Keyboard shortcuts

| Keys | Action |
| --- | --- |
| `←` `→` or `h` `l` | previous / next year |
| `↑` `↓` or `j` `k` | move selection (hold to accelerate) |
| `Enter` or `o` | open selected story |
| `c` | open HN discussion |
| `1`–`9` | open story #1–#9 |
| `/` | filter this year's list (`Esc` clears) |
| `y` / `Shift+y` | copy article / discussion link |
| `g` + year + `Enter` | jump to a year (e.g. `g` `2015` `Enter`) |
| `?` | help overlay |
| `Esc` | close / cancel / clear |

## Files

- `index.html` — the site; deploy this one file anywhere static
- `sw.js`, `manifest.webmanifest`, `icon.svg` — optional PWA support
- `template.html`, `template.sw.js`, `data.json` — sources
- `build.py` — rebuild: `python3 build.py`
- `fetch_top_stories.py` — refresh the data from the HN Search API

## Data

Top 25 stories per year, ranked by points, from the public
[HN Search API](https://hn.algolia.com/api) at fetch time. Not affiliated
with Hacker News or Y Combinator. See `CHANGELOG.md` for version history.
