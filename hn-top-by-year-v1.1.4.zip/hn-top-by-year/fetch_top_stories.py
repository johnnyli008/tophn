#!/usr/bin/env python3
"""
hn-top-by-year :: data builder
Fetches the highest-scoring Hacker News stories for each year from the
Algolia HN Search API (https://hn.algolia.com/api) and writes a compact
JSON payload that gets embedded into the static site.

Usage:
    python3 fetch_top_stories.py [--out data.json] [--top 25] [--first 2007]

The output file is deterministic apart from `generated_at`. Re-run it any
time to refresh the dataset before a release (e.g. when a new year starts
or older stories accumulate more points).
"""

import argparse
import json
import sys
import time
import urllib.parse
import urllib.request
from datetime import datetime, timezone, date

API = "https://hn.algolia.com/api/v1/search"
UA = "hn-top-by-year-builder/1.0 (static site data build)"

# A short, polite pause between API calls.
THROTTLE_SEC = 0.4


def fetch_year(year: int, top_n: int) -> list:
    """Return the top_n stories (by points) posted in the given calendar year."""
    start = int(datetime(year, 1, 1, tzinfo=timezone.utc).timestamp())
    end = int(datetime(year + 1, 1, 1, tzinfo=timezone.utc).timestamp())
    now = int(datetime.now(timezone.utc).timestamp())
    if start > now:
        raise ValueError(f"year {year} is in the future")
    end = min(end, now + 86400)  # allow current, still-running year

    params = {
        "tags": "story",
        "numericFilters": f"created_at_i>{start},created_at_i<{end}",
        "hitsPerPage": 100,
    }
    url = f"{API}?{urllib.parse.urlencode(params)}"
    req = urllib.request.Request(url, headers={"User-Agent": UA})

    for attempt in range(3):
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                payload = json.load(resp)
            break
        except Exception as exc:  # noqa: BLE001 - retry any transport error
            if attempt == 2:
                raise RuntimeError(f"failed to fetch {year}: {exc}") from exc
            time.sleep(1.5 * (attempt + 1))

    stories = []
    seen = set()
    for hit in payload.get("hits", []):
        title = (hit.get("title") or "").strip()
        if not title:  # deleted / flagged stories can have empty titles
            continue
        oid = hit.get("objectID")
        if not oid or oid in seen:
            continue
        seen.add(oid)
        url_attr = (hit.get("url") or "").strip()
        stories.append(
            {
                "id": int(oid),
                "title": title,
                "url": url_attr or None,  # None => link to the HN item itself
                "points": int(hit.get("points") or 0),
                "comments": int(hit.get("num_comments") or 0),
                "author": hit.get("author") or "?",
                "date": (hit.get("created_at") or "")[:10],
            }
        )

    stories.sort(key=lambda s: (-s["points"], -s["comments"]))
    return stories[:top_n]


def domain_of(url):
    if not url:
        return "news.ycombinator.com"
    netloc = urllib.parse.urlparse(url).netloc.lower()
    return netloc[4:] if netloc.startswith("www.") else (netloc or "news.ycombinator.com")


def main():
    ap = argparse.ArgumentParser(description=__doc__)
    ap.add_argument("--out", default="data.json")
    ap.add_argument("--top", type=int, default=25, help="stories kept per year")
    ap.add_argument("--first", type=int, default=2007, help="first year (HN launched Oct 2006)")
    args = ap.parse_args()

    this_year = date.today().year
    years = list(range(args.first, this_year + 1))
    print(f"Fetching top {args.top} stories for years {years[0]}-{years[-1]} ...")

    result = {"generated_at": datetime.now(timezone.utc).strftime("%Y-%m-%d"), "source": "hn.algolia.com/api/v1", "years": []}
    total = 0
    for y in years:
        stories = fetch_year(y, args.top)
        for s in stories:
            s["domain"] = domain_of(s["url"])
        result["years"].append(
            {
                "year": y,
                "partial": y == this_year,  # current year is still in progress
                "stories": stories,
            }
        )
        total += len(stories)
        peak = stories[0] if stories else None
        peak_txt = f'peak: {peak["points"]} pts - {peak["title"][:60]}' if peak else "no data"
        print(f"  {y}: {len(stories):2d} stories  ({peak_txt})")
        time.sleep(THROTTLE_SEC)

    with open(args.out, "w", encoding="utf-8") as fh:
        json.dump(result, fh, ensure_ascii=False, separators=(",", ":"))

    size_kb = len(json.dumps(result, ensure_ascii=False).encode()) / 1024
    print(f"\nWrote {args.out}: {total} stories, {size_kb:.0f} KB")
    return 0


if __name__ == "__main__":
    sys.exit(main())
